<?php
$keyId = '';
$keySecret = 's4XXYQeWoaVmrHi8hw093Zd3';
$displayCurrency = 'INR';

$appName="Glintel Technologies";
$appDesc="Pay you fees, with our payment gateway";
$appImg="";
$curreny="INR";

//These should be commented out in production
// This is for error reporting
// Add it to config.php to report any errors
error_reporting(E_ALL);
ini_set('display_errors', 1);
