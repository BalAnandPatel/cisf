<html>
  <head>
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:400,400i,700,900&display=swap" rel="stylesheet">
  </head>
  <link rel="stylesheet" href="../css/success.css">
    <body>
      <div class="card">
      <div style="border-radius:200px; height:200px; width:200px; background: #F8FAF5; margin:0 auto;">
        <i class="checkmark">✓</i>
      </div>
        <h1>Success</h1> 
        <table>
            <tr><td><b>TxnID : </b></td><td> <p><?php echo $txnId?></p></td></tr>
            <tr><td><b>Order ID : </b></td><td> <p><?php echo $orderId?></td></td></tr>
            <tr><td><b>Form ID : </b></td> <td><p><?php echo $shoppingId?></td></td></tr>
            <tr><td><b>Date: </b></td><td> <p><?php echo date("d-m-Y h:i:sa")?></td></td></tr>
            </table>
   
      </div>
    </body>
</html>